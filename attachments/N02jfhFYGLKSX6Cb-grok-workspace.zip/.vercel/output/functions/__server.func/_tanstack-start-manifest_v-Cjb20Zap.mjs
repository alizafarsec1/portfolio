//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cjb20Zap.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/projects/$slug"],
		preloads: ["/assets/index-PbsQty8Y.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-PbsQty8Y.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-9z73dV2m.js", "/assets/chrome-BI7t9yAB.js"]
	},
	"/projects/$slug": {
		filePath: "/workspace/src/routes/projects.$slug.tsx",
		children: void 0,
		preloads: ["/assets/projects._slug-Ccbtf19y.js", "/assets/chrome-BI7t9yAB.js"]
	}
} });
//#endregion
export { tsrStartManifest };
